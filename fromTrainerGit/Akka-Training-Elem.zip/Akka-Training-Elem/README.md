h2. Overview

This is a bundle of complete and incomplete code snippets that help exploration of
basic concepts of Akka Actors. 

The directories are named in a pattern, for a purpose. Please follow the trainer's instructions.

While and after, adding to or modifying code, you may want to keep it in your preferred source code repository for later reference.

You may find mistakes in the code or comments. Please bring them up. Suggest corrections, whenever possible. That helps everyone.

