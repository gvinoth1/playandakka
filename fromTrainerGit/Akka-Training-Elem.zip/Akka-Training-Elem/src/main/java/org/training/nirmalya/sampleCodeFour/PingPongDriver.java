package org.training.nirmalya.sampleCodeFour;

public class PingPongDriver {

	public static void main(String[] args) {
		
		throw new RuntimeException("Not yet implemented!");

	}

}
