package org.training.nirmalya.sampleCodeSix;




import akka.actor.Props;
import akka.actor.UntypedActor;
import akka.japi.Creator;

public class PingActor extends UntypedActor {
	
	// TODO: Implement Props
	// TODO: Should accept Ping messages only
	@Override
	public void onReceive(Object arg0) throws Throwable {
		
	}
}
