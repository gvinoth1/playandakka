package org.training.nirmalya.sampleCodeFour;

import akka.actor.UntypedActor;

public class SmartPingActor extends UntypedActor {
	
	
	//TODO: Props is missing; implement.
	
	@Override
	public void onReceive(Object arg0) throws Throwable {
		// TODO Wait for trainer's instructions!

	}

}
