package org.training.nirmalya.sampleCodeSix;



import org.training.nirmalya.sampleCodeFour.PingPongMessageProtocol.PingMessage;

import akka.actor.Props;
import akka.actor.UntypedActor;
import akka.japi.Creator;

public class PongActor extends UntypedActor {
	
	// TODO: Implement Props
	// TODO: Should accept Pong messages only
	@Override
	public void onReceive(Object arg0) throws Throwable {
		
	}

}
